# Reconocimiento de voz con Matlab
Este es un proyecto básico de Reconocimiento de Voz implementado en Matlab que se desarrolló en el curso de Métodos Numéricos y Programación IV en el año 2014.

Se comparte este proyecto con fines educativos, con el objetivo de ser una ayuda al momento estudiar el reconocimento de voz.

El proyecto no soporta reconocimento de voz de terceros por lo cual es necesario que generes una nueva base de datos con la grabación tu voz en la carpeta BD(cambia todas las grabaciones para probarlo).

Para ver el programa en acción puedes visitar mi canal en youtube https://www.youtube.com/watch?v=p9ZgBoRlxwM
